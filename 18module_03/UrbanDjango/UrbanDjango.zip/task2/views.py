from django.shortcuts import render

# Create your views here.
def func_templ(request):
    return render(request, 'func_tempate.html')
